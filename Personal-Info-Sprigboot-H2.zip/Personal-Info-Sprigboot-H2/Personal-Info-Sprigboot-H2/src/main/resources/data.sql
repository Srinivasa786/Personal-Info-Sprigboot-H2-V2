insert into PERSON (
PERSON_ID,FIRST_NAME,LAST_NAME) values (
100,'Srinivasa', 'Duggempudi');

insert into ADDRESS (
PERSON_ID,ADDRESS_ID,STREET, CITY, STATE , POSTAL_CODE) values (
100,1,'HayathNagar', 'Hyd' , 'Telangana','1111111');

insert into ADDRESS (
PERSON_ID,ADDRESS_ID,STREET, CITY, STATE , POSTAL_CODE) values (
100,2,'LB Nagar', 'Hyd' , 'Telangana','1111122');